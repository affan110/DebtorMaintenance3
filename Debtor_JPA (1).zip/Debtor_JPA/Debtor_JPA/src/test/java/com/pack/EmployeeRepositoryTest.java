package com.pack;

import java.util.Optional;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import com.pack.model.Employee;
import com.pack.repository.EmployeeRepository;

@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
public class EmployeeRepositoryTest {

	@Autowired
	EmployeeRepository employeeRepository;

	static Employee e;

	static int id;

	@BeforeAll
	static void setUpBeforeClass() throws Exception {

		e = new Employee();
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
	}

	@Test

	public void saveEmployeeTest() {
		employeeRepository.save(e);
		id = e.getId();
		Assertions.assertNotNull(e.getId());

	}


}
