package com.pack.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pack.model.Employee;
import com.pack.repository.AdminRepository;
import com.pack.repository.EmployeeRepository;


@Service
public class AdminService {
	@Autowired
	EmployeeRepository employeeRepository;
	
	public void authorize(Employee emp) {
		 emp.setStatus("Authorized");
		 emp.setReason("Nil");
		employeeRepository.save(emp);
	}
	public Optional<Employee> getEmployee(int id){
	    return employeeRepository.findById(id);	  
	}
	public void reject(Employee emp,String reason) {
		emp.setStatus("Rejected");
		emp.setReason(reason);
	    employeeRepository.save(emp);
	}
	
}
