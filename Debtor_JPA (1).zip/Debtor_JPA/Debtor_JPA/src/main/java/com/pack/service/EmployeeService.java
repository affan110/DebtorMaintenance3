package com.pack.service;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pack.model.Employee;
import com.pack.repository.EmployeeRepository;

import com.pack.model.Employee;

@Service
public class EmployeeService {
	
	@Autowired
	EmployeeRepository employeeRepository;
	
	 
	public void saveEmployee(Employee employee) {
		employeeRepository.save(employee);
	 
		
	}

	
	  public void saveEmployee1(Employee emp) { emp.setStatus("Pending");
	  emp.setReason("Nil"); employeeRepository.save(emp); }
	 
	
	  public void saveEmployee2(Employee employee) { employee.setStatus("Pending");
	  employee.setReason("Nil"); employeeRepository.save(employee);
	  
	  
	  }
	 
	  public Optional<Employee> getEmployeeById(int id){
	  
	  
	  System.out.println("into");
	  return employeeRepository.findById(id);
	  
	  
	  
	  }
	  
		
	  
	  public void updateEmployee(Employee employee)
	  
	  { employee.setStatus("Pending");
		  employeeRepository.save(employee);
	 
	  
	  }
	  
	  
	  public List<Employee> viewAll()
	  {
		  
		  return employeeRepository.findAll();
	  }
	  
		
	 
	  public List<Employee> getEmployeeByName(String name) {
			return employeeRepository.findByName(name);
		}





















	







	







	
	 
}
