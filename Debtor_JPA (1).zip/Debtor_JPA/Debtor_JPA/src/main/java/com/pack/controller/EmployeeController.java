package com.pack.controller;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.pack.exception.EmployeeNotFoundException;
import com.pack.model.Employee;
import com.pack.service.EmployeeService;


@Controller
public class EmployeeController {
	
	final static Logger logger = LogManager.getLogger(EmployeeController.class);

	@Autowired
    EmployeeService employeeService;
	@RequestMapping("/")
	public String index() {
	return "Home";
	}
	
	@RequestMapping("/userlogin")
	public String userlogin() {
		return "userlogin";
	}
	@RequestMapping("/adminlogin")
	public String adminlogin() {
		return "adminlogin";
	}
	@RequestMapping("/login1")
	public String login() {
		return "index";
	}

	
	@RequestMapping("/add")
	public String toAdd( Model model) {
		
		  logger.info("into add");
		model.addAttribute( "empBean",new Employee());
		
		
	 		return  "emp";
		}
		
		 
		
	

	@RequestMapping("/save")
	public String saveEmp(@ModelAttribute("empBean") Employee employee)
	{ 
		  logger.info("into save");
	 
	 logger.error("Saving emp object"+employee);
		employeeService.saveEmployee(employee);
		return "welcome";
	}
	
	
	 @RequestMapping("/next") 
	  public String viewemp(Model m){
		  List<Employee>   list=employeeService.viewAll(); 
		  m.addAttribute("list",list); 
		  return "view";
		  }

	 @RequestMapping("/viewForm") 
	  public String viewemp11(Model m){
		  List<Employee>   list=employeeService.viewAll(); 
		  m.addAttribute("list",list); 
		  return "view";
		  }
	 @RequestMapping("/emp22")
		public String login2() {
			return "index";
		}
	 @RequestMapping("/emp2")
		public String login22() {
			return "employeeDetails";
		}
	  @RequestMapping(value="/getId", method = RequestMethod.GET)
	  public String  getId() {
	  
	  return "getIdForm"; 
	  }
	  
	  
	  @RequestMapping(value="/getIdMod", method = RequestMethod.GET) 
	  public String   getIdMod()
	  {
		  logger.info("into getIdMod");
	  return "getIdModForm";
	  
	  }
	  
	  
		


@RequestMapping(value="/update", method = RequestMethod.POST)  
public String update(@RequestParam("id") int  id,Model m)
{
	Employee employee=null;
	String page=null;
	try
			{
	 if (employeeService.getEmployeeById(id).isPresent())
	 {
		  employee=employeeService.getEmployeeById(id).get();
		  m.addAttribute("updateBean", employee);
		  page="showUpdateForm";
		 
	 }
	 else 
	  throw new EmployeeNotFoundException();
	   
		  
		}
		  catch(EmployeeNotFoundException e)
		  {
			  m.addAttribute("exception",e);
		    	page="ExceptionPage";
			 
		  }

     return page;
	
}


 @RequestMapping("/next1") 
 public String logi() { 
	 return "index"; 
	 }

 @RequestMapping("/addReg2") 
 public String log() { 
	 return "findByNameAndDesig"; 
	 }
 @RequestMapping("/review") 
 public String review() { 
	 return "employeeDetails"; 
	 }
 @RequestMapping("/home") 
 public String total() { 
	 return "Home"; 
	 }

 
 
  
  @RequestMapping("/findByNameAndDesig")
	public String findByName() {
		return "findByNameAndDesig";
	}

	@RequestMapping("/findByNameAndDesigMethod")
	public String findByNameAndDesigMethod(@RequestParam("name") String name, 
			Model m) {
		System.out.println(name);
		List<Employee> emp =  employeeService.getEmployeeByName(name);
		for (Employee employee : emp) {
			System.out.println(employee.getId());	
		}
		m.addAttribute("emp", emp);
		return "resultPage";
	}
	 
	 @RequestMapping("/pending")
		public String index11() {
		return "adminindex";}
	  @RequestMapping("/viewForm1") 
	  public String viewemp1(Model m){
		  List<Employee>   list=employeeService.viewAll(); 
		  m.addAttribute("list",list); 
		  return "pending";
		  }
			
			/*
			 * @RequestMapping("/viewForm11") public String viewemp2(Model m){
			 * List<Employee> list=employeeService.viewAll(); m.addAttribute("list",list);
			 * return "pending"; }
			 */
	  @RequestMapping("/select")
		public String select() {
			return "auth";
		}
		
			
			  @RequestMapping("/authorize") public String auth(@RequestParam("id") int id ) {
			  Optional<Employee> emp=employeeService.getEmployeeById(id); Employee
			  emp2=emp.get(); emp2.setStatus("Authorized");
			  employeeService.saveEmployee(emp2); return "redirect:/viewForm1";
			  
			  }
			  @RequestMapping("/rejectreason")  
			     public String reject()  {
				  logger.info("into rejecting debtor");
				     return "rejectreason";
			     }
			  @RequestMapping("/rejectreason1") public String rej(@RequestParam("id") int id ) {
				  Optional<Employee> emp=employeeService.getEmployeeById(id); Employee
				  emp2=emp.get(); emp2.setStatus("Rejected");
				  employeeService.saveEmployee(emp2); return "redirect:/viewForm1";
				  
				  }
		 
	 /* @RequestMapping("/authorize")  
	     public String authorize(@RequestParam("id") int id)  {
		 logger.info("into authorizing debtor");
		 Employee dbt=ad.getDebtor(id);
		 ad.authorize(dbt);
		 logger.info("Debtor was updated as authorized");
		 return "adminpage";}
			 
	     */
	  
}

 
