package com.pack.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotBlank;

@Entity
@Table(name = "debtor")
public class Employee {

	public Employee() {

	}

	/*
	 * public Employee(String name,String desig) {
	 * 
	 * this.name=name;
	 * 
	 * this.addressline1=addressline1;
	 * 
	 * }
	 */
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	int id;
	
	  @Column(name = "id")
	 

	public int getId() {
		return id;
	}

	

	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddressline1() {
		return addressline1;
	}

	public void setAddressline1(String addressline1) {
		this.addressline1 = addressline1;
	}

	public String getAddressline2() {
		return addressline2;
	}

	public void setAddressline2(String addressline2) {
		this.addressline2 = addressline2;
	}

	public String getFaxnumber() {
		return faxnumber;
	}

	public void setFaxnumber(String faxnumber) {
		this.faxnumber = faxnumber;
	}

	public String getPhonenumber() {
		return phonenumber;
	}

	public void setPhonenumber(String phonenumber) {
		this.phonenumber = phonenumber;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getBankname() {
		return bankname;
	}

	public void setBankname(String bankname) {
		this.bankname = bankname;
	}

	public String getBranchname() {
		return branchname;
	}

	public void setBranchname(String branchname) {
		this.branchname = branchname;
	}

	public String getSwiftaddress() {
		return swiftaddress;
	}

	public void setSwiftaddress(String swiftaddress) {
		this.swiftaddress = swiftaddress;
	}

	public String getAccountnumber() {
		return accountnumber;
	}

	public void setAccountnumber(String accountnumber) {
		this.accountnumber = accountnumber;
	}

	public String getAccountcurrency() {
		return accountcurrency;
	}

	public void setAccountcurrency(String accountcurrency) {
		this.accountcurrency = accountcurrency;
	}

	@Column(name = "debtorname")
	String name;
	@Column(name = "addressline1")
	String addressline1;
	@Column(name = "addressline2")
	String addressline2;

	@Column(name = "faxnumber")
	String faxnumber;
	@Column(name = "phonenumber")
	String phonenumber;
	@Column(name = "email")
	String email;
	@Column(name = "bankname")
	String bankname;
	@Column(name = "branchname")
	String branchname;
	@Column(name = "swiftaddress")
	String swiftaddress;
	@Column(name = "accountnumber")
	String accountnumber;
	@Column(name = "accountcurrency")
	String accountcurrency;

	@Column(name="status")
	String  status;
	@Column(name="reason")
	String  reason;

	public Employee(int id, String name, String addressline1, String addressline2, String faxnumber, String phonenumber,
			String email, String bankname, String branchname, String swiftaddress, String accountnumber,
			String accountcurrency, String status, String reason) {
		super();
		this.id = id;
		this.name = name;
		this.addressline1 = addressline1;
		this.addressline2 = addressline2;
		this.faxnumber = faxnumber;
		this.phonenumber = phonenumber;
		this.email = email;
		this.bankname = bankname;
		this.branchname = branchname;
		this.swiftaddress = swiftaddress;
		this.accountnumber = accountnumber;
		this.accountcurrency = accountcurrency;
		this.status = status;
		this.reason = reason;
	}

	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", addressline1=" + addressline1 + ", addressline2="
				+ addressline2 + ", faxnumber=" + faxnumber + ", phonenumber=" + phonenumber + ", email=" + email
				+ ", bankname=" + bankname + ", branchname=" + branchname + ", swiftaddress=" + swiftaddress
				+ ", accountnumber=" + accountnumber + ", accountcurrency=" + accountcurrency + "]";
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}



	
	  
	 
}
