package com.pack.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="employee")
public class Employee {
	
	public Employee()
	{
		
		
	}
	public Employee(String name,String desig)
	{
		
		this.name=name;
		this.addressline1=addressline1;
		
	}
	  @Id
	  @GeneratedValue(strategy = GenerationType.IDENTITY)
	  @Column(name="id")
	int id;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public String getAddressline1() {
		return addressline1;
	}
	public void setAddressline1(String addressline1) {
		this.addressline1 = addressline1;
	}
	
	
	
	public String getAddressline2() {
		return addressline2;
	}
	public void setAddressline2(String addressline2) {
		this.addressline2 = addressline2;
	}
	public String getFaxnumber() {
		return faxnumber;
	}
	public void setFaxnumber(String faxnumber) {
		this.faxnumber = faxnumber;
	}
	public String getPhonenumber() {
		return phonenumber;
	}
	public void setPhonenumber(String phonenumber) {
		this.phonenumber = phonenumber;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getBankname() {
		return bankname;
	}
	public void setBankname(String bankname) {
		this.bankname = bankname;
	}
	public String getBranchname() {
		return branchname;
	}
	public void setBranchname(String branchname) {
		this.branchname = branchname;
	}
	public String getSwiftaddress() {
		return swiftaddress;
	}
	public void setSwiftaddress(String swiftaddress) {
		this.swiftaddress = swiftaddress;
	}
	public String getAccountnumber() {
		return accountnumber;
	}
	public void setAccountnumber(String accountnumber) {
		this.accountnumber = accountnumber;
	}
	public String getAccountcurrency() {
		return accountcurrency;
	}
	public void setAccountcurrency(String accountcurrency) {
		this.accountcurrency = accountcurrency;
	}
	@Column(name="empname")
	String name;
	@Column(name="addressline1")
	String addressline1;
	@Column(name="addressline2")
	String addressline2;
	
	@Column(name="faxnumber")
	String faxnumber;
	@Column(name="phonenumber")
	String phonenumber;
	@Column(name="email")
	String email;
	@Column(name="bankname")
	String bankname;
	@Column(name="branchname")
	String branchname;
	@Column(name="swiftaddress")
	String swiftaddress;
	@Column(name="accountnumber")
	String accountnumber;
	@Column(name="accountcurrency")
	String accountcurrency;
	

}
